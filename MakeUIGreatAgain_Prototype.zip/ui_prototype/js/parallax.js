(function($){
  $(function(){
    $('.parallax').parallax();
  });
})(jQuery);
